// Wait for the DOM to be fully loaded before running the script
document.addEventListener('DOMContentLoaded', () => {
    // The base URL for The Cat API
    const baseURL = 'https://api.thecatapi.com/v1/images/search?include_breeds=true';
  
    // STEP 1: Paste your own API key below
    const apiKey = 'YOUR_API_KEY_HERE'; // 👈 Replace this with your real API key
  
    // Grab references to all the DOM elements you'll need
    const button = document.querySelector('.load-cat');
    const section = document.querySelector('.results');
  
    // STEP 2: Add a click event listener to the button, referencing the fetchCat function
    button.addEventListener('click', fetchCat);
  
    // Functions
    function fetchCat() {
      // STEP 3: Use fetch() to call the Cat API with the API key
      fetch(baseURL, {
        headers: {
          'x-api-key': apiKey
        }
      })
        .then(response => response.json())
        .then(data => displayResults(data))
        .catch(error => {
          console.error('Error fetching cat:', error);
        });
    }
  
    function displayResults(json) {
      // STEP 4: Log the result to the console
      console.log(json);
  
      // Clear previous results
      while (section.firstChild) {
        section.removeChild(section.firstChild);
      }
  
      // STEP 5: Extract cat image and breed info from JSON
      const catData = json[0];
      const imageUrl = catData.url;
      const breeds = catData.breeds;
  
      // Create elements to display the cat image and breed info
      const img = document.createElement('img');
      const breedText = document.createElement('p');
  
      img.src = imageUrl;
      img.alt = 'A random cat';
  
      // STEP 6: Check if breed info exists and show it
      if (breeds && breeds.length > 0) {
        breedText.textContent = `Breed: ${breeds[0].name}`;
      } else {
        breedText.textContent = 'Breed: Unknown';
      }
  
      breedText.classList.add('breed-info');
  
      // STEP 7: Append elements to the section
      section.appendChild(img);
      section.appendChild(breedText);
    }
  });
  